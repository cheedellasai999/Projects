package org.ps.components;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import java.io.IOException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.*;
import javax.naming.ldap.*;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.apache.log4j.Logger;

public class LDAPProcessor implements Callable {
	private LdapContext ctx = null;
	public static Logger logger = Logger.getLogger(LDAPProcessor.class);
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		MuleMessage msg = eventContext.getMessage();
		String user = msg.getInvocationProperty("user");
		String ldapFilter = "cn="+user;
		String ldapURL = msg.getInvocationProperty("ldapURL");
		String ldapBaseDN = msg.getInvocationProperty("ldapBaseDN");
		String ldapPrincipalDN = msg.getInvocationProperty("ldapPrincipalDN");
		String ldapPassword = msg.getInvocationProperty("ldapPassword");
		HashMap<String, String> ldapConnectMap = new HashMap<String, String>();
		ldapConnectMap.put("ldapURL", ldapURL);
		ldapConnectMap.put("ldapBaseDN", ldapBaseDN);
		ldapConnectMap.put("ldapPrincipalDN", ldapPrincipalDN);
		ldapConnectMap.put("ldapPassword", ldapPassword);
		connect(ldapConnectMap);
		HashMap<String, String> result = new HashMap<String, String>();
		result.put("cn", "cn value");
		result.put("sn", "sn value");
		result.put("givenName", "givenName value");
		SearchControls searchCtls = new SearchControls();
	    searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);
	    searchCtls.setTimeLimit(30000);
	    searchCtls.setReturningAttributes(new String[]{"*","+"});	    
	    int pageSize = 100;
	    byte[] cookie = null;
	    HashMap<String,String> userMap = new HashMap<String, String>();
	    int myPage = 1;
	    do{	    
			NamingEnumeration<SearchResult> results = this.ctx.search(ldapBaseDN, ldapFilter, searchCtls);
			logger.info("sso-intgr-svc-impl edir results:"+  (results != null));
			while (results != null && results.hasMore()) {
				SearchResult sr = (SearchResult) results.next();
				Attributes attrs = sr.getAttributes();
				userMap.put("dn", sr.getNameInNamespace());
				userMap.put("cn", getAttributeByValue(attrs.get("cn")));
				userMap.put("sn", getAttributeByValue(attrs.get("sn")));
				userMap.put("givenName", getAttributeByValue(attrs.get("givenName")));
			}
			
			if(!userMap.containsKey("cn"))
			{
				userMap.put("dn", "");
				userMap.put("cn", "");
				userMap.put("sn", "");
				userMap.put("givenName", "");
			}
			
			Control[] controls = this.ctx.getResponseControls();
			if (controls != null) {
							for (int i = 0; i < controls.length; i++) {
											if (controls[i] instanceof PagedResultsResponseControl) {
															PagedResultsResponseControl prrc = (PagedResultsResponseControl) controls[i];
															cookie = prrc.getCookie();
											}
							}

			}	    
			this.ctx.setRequestControls(new Control[] { new PagedResultsControl(pageSize, cookie, Control.CRITICAL) });
	    } while (cookie != null);	    
	    logger.info("sso-intgr-svc-impl edir userMap:"+userMap.toString());
	    return userMap;
	}
	
	
	
	
	
	private String getAttributeByValue(Attribute attr) throws NamingException {
	        StringBuilder value = new StringBuilder();
	        if (attr != null) {
	                        if (attr.size() == 1) {
	                                        value.append(attr.get(0).toString());
	                        } else {
	                                        for (int i = 0; i < attr.size(); i++) {
	                                                        value.append("[");
	                                                        value.append(attr.get(i).toString());
	                                                        value.append("]");
	                                        }
	                        }
	        }
	        return value.toString();
	}

	private void connect(HashMap<String, String> ldapDataMap) {
		new TrustSelfSignedSSL();
		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, ldapDataMap.get("ldapURL"));
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, ldapDataMap.get("ldapPrincipalDN"));
		env.put(Context.SECURITY_CREDENTIALS, ldapDataMap.get("ldapPassword"));
		env.put(Context.SECURITY_PROTOCOL, "ssl");
		try {
			this.ctx = new InitialLdapContext(env, null);
		} catch (NamingException ne) {
			logger.error("sso-intgr-svc-impl edir get users connect failed:",ne);
		}
	}

	static class TrustSelfSignedSSL {
		public TrustSelfSignedSSL() {
			try {
				SSLContext ctx = SSLContext.getInstance("TLS");
				X509TrustManager tm = new X509TrustManager() {
					public void checkClientTrusted(X509Certificate[] xcs, String string) throws CertificateException {
					}

					public void checkServerTrusted(X509Certificate[] xcs, String string) throws CertificateException {
					}

					public X509Certificate[] getAcceptedIssuers() {
						return null;
					}
				};
				ctx.init(null, new TrustManager[] { tm }, null);
				SSLContext.setDefault(ctx);
			} catch (Exception ex) {
				logger.error("sso-intgr-svc-impl edir get users TrustSelfSignedSSL:",ex);
			}
		}
	}
}
