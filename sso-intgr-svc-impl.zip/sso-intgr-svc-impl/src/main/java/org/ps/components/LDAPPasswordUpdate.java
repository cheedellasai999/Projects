package org.ps.components;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.*;
import javax.naming.ldap.*;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.apache.log4j.Logger;

public class LDAPPasswordUpdate implements Callable {
	private LdapContext ctx = null;
	public static Logger logger = Logger.getLogger(LDAPPasswordUpdate.class);
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		MuleMessage msg = eventContext.getMessage();
		String dn = msg.getInvocationProperty("dn");
		String userPassword = msg.getInvocationProperty("password");
		String ldapURL = msg.getInvocationProperty("ldapURL");
		String ldapPrincipalDN = msg.getInvocationProperty("ldapPrincipalDN");
		String ldapPassword = msg.getInvocationProperty("ldapPassword");
		HashMap<String, String> ldapConnectMap = new HashMap<String, String>();
		ldapConnectMap.put("ldapURL", ldapURL);
		ldapConnectMap.put("ldapPrincipalDN", ldapPrincipalDN);
		ldapConnectMap.put("ldapPassword", ldapPassword);
		connect(ldapConnectMap);
		
		HashMap<String, String> userMap = new HashMap<String, String>();
		
		ModificationItem[] mods = new ModificationItem[1];
        mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute("userPassword", userPassword));
        try{
        	this.ctx.modifyAttributes(dn, mods);
        	userMap.put("success", "true");
        }catch (Exception ex){
        	userMap.put("success", "false");
        	logger.error("sso-intgr-svc-impl edir password update failed:",ex);
        }
        return userMap;
	}
	
		
	private void connect(HashMap<String, String> ldapDataMap) {
		new TrustSelfSignedSSL();
		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, ldapDataMap.get("ldapURL"));
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, ldapDataMap.get("ldapPrincipalDN"));
		env.put(Context.SECURITY_CREDENTIALS, ldapDataMap.get("ldapPassword"));
		env.put(Context.SECURITY_PROTOCOL, "ssl");
		try {
			this.ctx = new InitialLdapContext(env, null);
		} catch (NamingException ne) {
			logger.error("sso-intgr-svc-impl edir password update connect failed:",ne);
		}
	}

	static class TrustSelfSignedSSL {
		public TrustSelfSignedSSL() {
			try {
				SSLContext ctx = SSLContext.getInstance("TLS");
				X509TrustManager tm = new X509TrustManager() {
					public void checkClientTrusted(X509Certificate[] xcs, String string) throws CertificateException {
					}

					public void checkServerTrusted(X509Certificate[] xcs, String string) throws CertificateException {
					}

					public X509Certificate[] getAcceptedIssuers() {
						return null;
					}
				};
				ctx.init(null, new TrustManager[] { tm }, null);
				SSLContext.setDefault(ctx);
			} catch (Exception ex) {
				logger.error("sso-intgr-svc-impl edir password update TrustSelfSignedSSL:",ex);
			}
		}
	}
}
