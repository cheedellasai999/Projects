package org.ps.components;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;

public class Payload_transform extends AbstractTransformer {
    
    String s;
    @Override
    protected Object doTransform(Object src, String enc)
            throws TransformerException {
    	
    	String temp = ((String) src);
    	String s1= temp.replace("}{", "},{");
    	
    	s="[" + s1 + "]";
    	
    	return s;
    }

}
