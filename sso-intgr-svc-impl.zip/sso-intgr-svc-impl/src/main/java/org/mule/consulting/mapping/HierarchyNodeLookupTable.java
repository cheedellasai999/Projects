package org.mule.consulting.mapping;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;

public class HierarchyNodeLookupTable implements Callable {
	private static Log logger = LogFactory.getLog(HierarchyNodeLookupTable.class);
	public ArrayList<LinkedHashMap> dataValues = null;
	public ConcurrentHashMap<String, LinkedHashMap> index = null;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		this.dataValues = (ArrayList<LinkedHashMap>) eventContext.getMessage()
				.getPayload();
		this.index = new ConcurrentHashMap<String, LinkedHashMap>();
		for (LinkedHashMap value : dataValues) {
			index.put((String) value.get("node"), value);
		}
		return this;
	}

	/**
	 * Provide a flattened parentage Map. Will return levelxx_name and
	 * levelxx_id for all the parents up to and including level01.
	 * 
	 * @param node
	 *            the node id
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public HashMap parentage(String node) {
		if (node == null)
			return null;
		LinkedHashMap currentItem = index.get(node);

		if (currentItem == null)
			return null;
		LinkedHashMap currentData = (LinkedHashMap) currentItem.get("data");
		if (currentData == null)
			return null;
		logger.debug("currentItem: " + currentItem);
		logger.debug("currentData: " + currentData);

		HashMap v = new HashMap();
		int level = ((Integer) currentData.get("treeLevel")).intValue();
		logger.debug("treeLevel: " + level);

		while (level > 1 && currentItem != null && currentData != null) {
			level--;
			currentItem = index.get(currentData.get("parent"));
			logger.debug("currentItem: " + currentItem);
			if (currentItem != null) {
				currentData = (LinkedHashMap) currentItem.get("data");
				logger.debug("currentData: " + currentData);
				if (currentData != null) {
					String prefix = "level0" + Integer.toString(level) + "_";
					v.put(prefix + "name", currentData.get("ltext"));
					v.put(prefix + "id", currentItem.get("node"));
				}
			}
		}

		return v;
	}
}
